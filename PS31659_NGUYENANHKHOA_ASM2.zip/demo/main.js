var app = angular.module("myApp", ["ngRoute"]);
      app.controller("myCtrl",function ($scope, $rootScope, $routeParams, $http) {
          $scope.products = [];
          //Đọc dữ liệu từ file json
          $http.get("data.json").then(function (reponse) {
            $scope.products = reponse.data;
            //Khúc này là chuyển từ id để lấy sản phẩm 
            $scope.detailPro=$scope.products.find(item=>item.id==$routeParams.id);
          });
          $scope.addCart = function (product){
            if(typeof $rootScope.cart=='undefined'){
              $rootScope.cart=[];
            };
            var index = $rootScope.cart.findIndex((item) => item.id == product.id);
            if(index == -1){
              product.quantity = 1;
              $rootScope.cart.push(product);
            }else{
              $rootScope.cart[index].quantity++;
            }
            console.log($rootScope.cart);
          };
          $scope.removeCart = function(){
            $scope.cart.splice($scope.index,1);
            $scope.clear()
          };
          $scope.total = function(){
            var tt = 0;
            for(i=0; i<$scope.cart.length; i++){
              tt += $rootScope.cart[i].quantity * $scope.cart[i].sale;
            } 
            return tt;
          };
          $scope.sort='sale';
            $scope.tang=function(){
                $scope.sort='sale';
            }
            $scope.giam=function(){
                $scope.sort='-sale';
            }
            $scope.show=false;
            // $scope.searchSP=function(){
            //     if(typeof $scope.search!='undefined'){
            //     $scope.show=true;
            // } }
        }
      );

      app.config(function ($routeProvider) {
        $routeProvider
          .when("/about", {
            templateUrl: "about.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/home", {
            templateUrl: "home.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/dulich", {
            templateUrl: "dulich.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/review", {
            templateUrl: "review.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/detail", {
            templateUrl: "detail.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/login", {
            templateUrl: "login.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/register", {
            templateUrl: "register.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/detail/:id", {
            templateUrl: "detailProduct.html?" + Math.random(),
            controller: "myCtrl",
          })
          .when("/home1", {
            templateUrl: "home1.html?" + Math.random(),
            controller: "myCtrl",
          })
          .otherwise({
            templateUrl: "home.html",
            controller: "myCtrl",
          });
      });
      
      var ab = angular.module("myapp1", []);
      ab.controller1("myctrl1", function ($scope) {
        


});